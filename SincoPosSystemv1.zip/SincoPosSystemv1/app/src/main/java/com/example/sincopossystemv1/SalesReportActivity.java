package com.example.sincopossystemv1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SalesReportActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sales_report);
    }
}